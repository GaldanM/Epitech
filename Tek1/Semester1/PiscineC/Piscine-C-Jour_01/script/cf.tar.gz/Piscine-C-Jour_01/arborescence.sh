cd /home/moulin_c/rendu/Piscine-C-Jour_01 
echo .:
ls
echo
echo ./cf:
ls cf
echo
echo ./perso:
ls perso
echo
echo ./Perso
ls Perso
echo
echo ./personnel
ls personnel 
echo
echo ./Personnel
ls Personnel
